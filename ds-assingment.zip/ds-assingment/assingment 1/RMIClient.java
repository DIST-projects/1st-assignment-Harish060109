import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.Map;

/*
 * RMIClient
 * ---------
 * Client program to access remote StudentService
 * hosted on AWS EC2.
 */
public class RMIClient {

    public static void main(String[] args) {
        try {
            // Connect to RMI registry on AWS EC2
            Registry registry =
                LocateRegistry.getRegistry("16.171.30.218", 1099);

            // Lookup remote object
            StudentService service =
                (StudentService) registry.lookup("StudentService");

            // Invoke remote methods
            System.out.println(service.addStudent("CS101", "Arjun", 82));
            System.out.println(service.getStudent("CS101"));
            System.out.println(service.calculateGrade("CS101"));

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
